package com.airline.baggage.enums;

public enum BaggageStatus {
    PURCHASED,
    REFUNDED
}