package com.airline.baggage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaggageServiceApplication {
    public static void main(final String[] args) {
        SpringApplication.run(BaggageServiceApplication.class, args);
    }
}