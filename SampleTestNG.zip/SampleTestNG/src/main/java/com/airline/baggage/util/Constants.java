package com.airline.baggage.util;

import java.math.BigDecimal;
import java.time.Duration;

public final class Constants {
    public static final BigDecimal BASE_PRICE_PER_KG = new BigDecimal("20.00");
    public static final BigDecimal DISCOUNT_RATE = new BigDecimal("0.30");
    public static final BigDecimal DISCOUNTED_PRICE_PER_KG =
        BASE_PRICE_PER_KG.multiply(BigDecimal.ONE.subtract(DISCOUNT_RATE));
    public static final BigDecimal DEFAULT_COMPLIMENTARY_BAGGAGE_KG = new BigDecimal("20.00");
    public static final BigDecimal MIN_WEIGHT_PER_PURCHASE_KG = new BigDecimal("0.01");
    public static final BigDecimal MAX_WEIGHT_PER_PURCHASE_KG = new BigDecimal("100.00");
    public static final Duration PURCHASE_TIME_RESTRICTION = Duration.ofHours(1);
    public static final String CHANNEL_HEADER = "X-Channel";
    public static final String CURRENCY_CODE = "USD";

    private Constants() {
    }
}