package com.airline.baggage.enums;

public enum PurchaseChannel {
    WEB,
    IOS,
    ANDROID
}