package com.airline.baggage.enums;

public enum BookingStatus {
    BOOKED,
    CANCELLED,
    COMPLETED
}