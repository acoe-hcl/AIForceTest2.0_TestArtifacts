package com.airline.baggage.config;

import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI baggageOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("Additional Baggage Allowance API")
                .description("API for purchasing additional baggage")
                .version("v1")
                .contact(new Contact()
                    .name("Airline")
                    .email("support@example.com")))
            .externalDocs(new ExternalDocumentation()
                .description("Swagger UI")
                .url("/swagger-ui.html"));
    }
}