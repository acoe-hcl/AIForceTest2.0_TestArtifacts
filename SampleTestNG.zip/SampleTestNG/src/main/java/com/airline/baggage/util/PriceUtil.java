package com.airline.baggage.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class PriceUtil {
    private static final int MONEY_SCALE = 2;

    private PriceUtil() {
    }

    public static BigDecimal multiplyMoney(final BigDecimal a, final BigDecimal b) {
        try {
            return a.multiply(b).setScale(MONEY_SCALE, RoundingMode.HALF_UP);
        } catch (Exception ex) {
            throw new IllegalArgumentException("Invalid money multiplication", ex);
        }
    }

    public static BigDecimal addMoney(final BigDecimal a, final BigDecimal b) {
        return a.add(b).setScale(MONEY_SCALE, RoundingMode.HALF_UP);
    }
}