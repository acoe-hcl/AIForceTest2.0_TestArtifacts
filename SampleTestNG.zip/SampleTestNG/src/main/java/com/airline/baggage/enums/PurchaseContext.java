package com.airline.baggage.enums;

public enum PurchaseContext {
    DURING_BOOKING,
    POST_BOOKING
}